import React, { useState } from "react";
import "./landing.css";

export default function BBAAdmission() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/BBA-Flayer.jpeg" alt="Commerce Admission Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right" style={{ padding: 26 }}>
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>Commerce & Management Admission Group</h1>

            <p>
              Unlock your potential in the world of business and management! 📈💼 Whether you are aiming for an IPM at an IIM or looking to secure a seat in a leading private university, <b>Abhinav Career Scope</b> is here to streamline your journey with our exclusive <b>Admission WhatsApp Paid Group for Commerce!</b>
            </p>

            <p>
              Navigating the competitive landscape of management entrance exams requires timely information and strategic planning.
            </p>

            {/* ✅ INNER CARD (KEEP UI CONSISTENT) */}
            <div className="inner-card">
              <h3>📊 Why Join Our Commerce & Management Group?</h3>

              <div className="list-cards">

                <div className="list-card">
                  <b>Critical Timelines</b>
                  <p>Get real-time alerts for Important Dates and Rules so you never miss a deadline.</p>
                </div>

                <div className="list-card">
                  <b>IIM & University Insights</b>
                  <p>Guidance on Admission process of IIM through IPM and leading private universities.</p>
                </div>

                <div className="list-card">
                  <b>Official Notifications</b>
                  <p>Receive direct notifications from the website curated for relevance.</p>
                </div>

                <div className="list-card">
                  <b>Interactive Support</b>
                  <p>Participate in Q&A sessions and find answers to frequently asked questions.</p>
                </div>

              </div>
            </div>
<br/>
            <h3>🎓 Guided by Industry Experts</h3>

            <p>
              Led by <b>Reena Bhutada</b>, a National Award-Winning Career Counselor with over <b>18 years of experience</b>, Abhinav Career Scope helps bridge the gap between education and employability.
            </p>

            

          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Connect with Us</h3>
              <p>
              Your professional career starts with the right choice today. Join our community for expert guidance and premium admission updates.
            </p>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              Abhinav Career Scope — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}