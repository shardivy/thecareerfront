import React, { useState } from "react";
import "./landing.css";

export default function MedicalNeetGroup() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/Medical-WP-Flayer.jpeg" alt="Medicala Admission Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right" style={{ padding: 26 }}>
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>NEET Admission WhatsApp Group</h1>

            <p>
              Your medical career is a high-stakes journey—don't leave it to chance! 🩺✨ Navigating the NEET UG counseling process can be complex, but <b>Abhinav Career Scope</b> is here to ensure you stay ahead with our specialized <b>Admission WhatsApp Paid Group for NEET!</b>
            </p>

            <p>
              Join a community of focused aspirants and receive real-time updates directly from experts to secure your dream seat in the medical field.
            </p>

            {/* ✅ INNER CARD */}
            <div className="inner-card">
              <h3>🏥 Why Join Our Medical Admission Group?</h3>

              <div className="list-cards">

                <div className="list-card">
                  <b>Critical Timelines</b>
                  <p>Stay informed with all Important Dates for registrations, results, and rounds.</p>
                </div>

                <div className="list-card">
                  <b>Process Roadmap</b>
                  <p>Understand complete Admission Process for AIQ, State Quota & Deemed Universities.</p>
                </div>

                <div className="list-card">
                  <b>Technical Guidance</b>
                  <p>Get updates on Exams & Rules with smart Options Form Tips.</p>
                </div>

                <div className="list-card">
                  <b>Expert Q&A</b>
                  <p>Get answers to questions about cutoffs and college selection.</p>
                </div>

              </div>
            </div>
<br></br>
            <h3>💼 Expert Mentorship</h3>

            <p>
              Led by <b>Reena Bhutada</b>, a National Award-Winning Career Counselor with over <b>18 years of experience</b>, we help bridge the gap between education and employability across India.
            </p>
          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Connect with Us</h3>
              <p> Don't let technicalities stop your doctor dreams. Join our exclusive WhatsApp group for premium guidance!</p>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              Abhinav Career Scope — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}