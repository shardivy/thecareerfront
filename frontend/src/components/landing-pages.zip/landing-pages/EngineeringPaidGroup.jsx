import React, { useState } from "react";
import "./landing.css";

export default function EngineeringPaidGroup() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 9922695424";
  const phone2 = "+91 8208030557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/Engg-WP-Flayer.jpeg" alt="Engineering Admission Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* SCROLL */}
          <div className="scroll-content">

            <h1>Paid Group for Engineering Admission Update</h1>

            <p>
              This group is designed to help parents stay informed about the Engineering Admission process.
            </p>

            {/* HIGHLIGHTS */}
            <div className="inner-card">
              <h3>📌 Key Highlights</h3>

              <div className="list-cards">

                <div className="list-card">
                  <b>Important Dates & Deadlines</b>
                  <p>Stay updated with all crucial admission timelines.</p>
                </div>

                <div className="list-card">
                  <b>Admission Process Details</b>
                  <p>IIT, NIT, MHTCET, BITSAT & Private Universities.</p>
                </div>

                <div className="list-card">
                  <b>Rules & Guidelines</b>
                  <p>Understand admission rules clearly.</p>
                </div>

                <div className="list-card">
                  <b>Official Notifications</b>
                  <p>Updates directly from relevant websites.</p>
                </div>

                <div className="list-card">
                  <b>Q&A Support</b>
                  <p>Get answers to common queries.</p>
                </div>

                <div className="list-card">
                  <b>FAQs Support</b>
                  <p>Clear answers to frequently asked questions.</p>
                </div>

              </div>
            </div>

            <p>
              The group will remain active until the admission process concludes.
            </p>

            {/* NOTE */}
            <div className="inner-card">
              <h3>📌 Note</h3>

              <div className="list-cards">

                <div className="list-card">
                  <b>End-to-End Admission Guidance</b>
                  <p>
                    JEE (Main & Advanced), JoSAA Counseling, MHTCET Process.
                  </p>
                </div>

                <div className="list-card">
                  <b>Charges</b>
                  <p>Will vary based on the admission process.</p>
                </div>

                <div className="list-card">
                  <b>Free E-Book</b>
                  <p>Engineering Cutoff E-Book available for parents.</p>
                </div>

                <div className="list-card">
                  <b>Other Services</b>
                  <p>Additional services will be charged separately.</p>
                </div>

                <div className="list-card">
                  <b>One Parent Policy</b>
                  <p>Only one parent number allowed per payment.</p>
                </div>

                <div className="list-card">
                  <b>No Personal Prediction</b>
                  <p>
                    College/branch prediction not provided in group.
                  </p>
                </div>

                <div className="list-card">
                  <b>FAQs Document</b>
                  <p>Shared after registration for all queries.</p>
                </div>

                <div className="list-card">
                  <b>Response Time</b>
                  <p>Queries answered within 24 hours.</p>
                </div>

              </div>
            </div>

          </div>

          {/* FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Contact Us</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>🏦 Abhinav Career Scope, Pune</b>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}