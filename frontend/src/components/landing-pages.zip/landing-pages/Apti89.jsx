import React, { useState } from "react";
import "./landing.css";

export default function Apti89() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/8-12Aptitude-Flayer.jpeg" alt="8th 9th Aptitude Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>Career Guidance for 8th & 9th Students</h1>

            <p>
              Confused about your future studies and career options? 🌟
              This is the perfect time to discover your hidden talents and strengths.
            </p>

            <p>
              Students of <b>8th and 9th standard</b> are at an important stage where the right guidance can shape a bright future. 
              <b> Abhinav Career Scope</b> helps students understand their interests, abilities, and the best career directions from an early age. 🚀
            </p>

            <h3>🌟 Meet Your Mentor: Reena Bhutada</h3>

            <p>
              Get guidance from <b>Reena Bhutada</b>, a National Award-Winning Career Counselor, who has helped thousands of students choose the right path with confidence and clarity.
            </p>

            <h3>🧠 What We Offer</h3>

            <p>
              Our specially designed program for school students focuses on self-discovery, confidence building, and career awareness.
            </p>

            <div className="list-cards">

              <div className="list-card">
                <b>Scientific Aptitude Test</b>
                <p>
                  Identify your natural strengths, talents, personality, and learning style through expert-designed aptitude assessments.
                </p>
              </div>

              <div className="list-card">
                <b>Career Awareness Guidance</b>
                <p>
                  Explore exciting future career opportunities and understand which streams and subjects match your interests best.
                </p>
              </div>

              <div className="list-card">
                <b>Personalized Counselling</b>
                <p>
                  One-on-one counselling sessions for students and parents to help make informed academic and career decisions.
                </p>
              </div>

            </div>

            <br />

            <h3>📚 Why Start Early?</h3>

            <ul>
              <li>Build confidence in career decisions</li>
              <li>Understand strengths and weaknesses</li>
              <li>Choose the right stream in future</li>
              <li>Reduce confusion and stress about careers</li>
            </ul>

            <h3>📞 Get Started Today!</h3>

            <p>
              Give your child the right direction at the right time and help them build a successful future. 🌈
            </p>

            <ul>
              <li>
                Scan the QR Code in the flyer to join our WhatsApp Group for updates, guidance, and career tips.
              </li>
            </ul>

          </div>

          {/* STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Call Us Directly</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> – Your Perfect Career Guide.
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}