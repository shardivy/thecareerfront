import React, { useState } from "react";
import "./landing.css";

export default function Apti1112() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/8-12Aptitude-Flayer.jpeg" alt="11th 12th Aptitude Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>Career Guidance for 11th & 12th Students</h1>

            <p>
              Worried about your future career, college admissions, or competitive exams? 🎯
              You are not alone.
            </p>

            <p>
              Students in <b>11th and 12th standard</b> face some of the most important academic and career decisions of their lives. 
              <b> Abhinav Career Scope</b> helps students discover the best career opportunities based on their interests, aptitude, and future goals. 🚀
            </p>

            <h3>🌟 Meet Your Mentor: Reena Bhutada</h3>

            <p>
              Get expert guidance from <b>Reena Bhutada</b>, a National Award-Winning Career Counselor, who has successfully guided thousands of students toward the right career path and higher education choices.
            </p>

            <h3>🧠 What We Offer</h3>

            <p>
              Our specially designed counselling program helps students gain clarity about courses, careers, entrance exams, and future opportunities.
            </p>

            <div className="list-cards">

              <div className="list-card">
                <b>Scientific Aptitude & Career Assessment</b>
                <p>
                  Understand your strengths, personality, interests, and career suitability through professional aptitude testing.
                </p>
              </div>

              <div className="list-card">
                <b>Career & Course Selection Guidance</b>
                <p>
                  Explore the best career options, degree courses, entrance exams, and college pathways according to your goals.
                </p>
              </div>

              <div className="list-card">
                <b>Personalized Counselling Sessions</b>
                <p>
                  One-on-one counselling sessions for students and parents to help make confident and informed career decisions.
                </p>
              </div>

            </div>

            <br />

            <h3>📚 Why Career Guidance Matters?</h3>

            <ul>
              <li>Choose the right career path with confidence</li>
              <li>Understand college and course opportunities</li>
              <li>Get clarity about entrance exams and future planning</li>
              <li>Avoid confusion, stress, and wrong career choices</li>
            </ul>

            <h3>📞 Get Started Today!</h3>

            <p>
              Your future deserves the right guidance. Take the first step toward a successful and fulfilling career today. 🌈
            </p>

            <ul>
              <li>
                Scan the QR Code in the flyer to join our WhatsApp Group for updates, counselling sessions, and career guidance tips.
              </li>
            </ul>

          </div>

          {/* STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Call Us Directly</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> – Your Perfect Career Guide.
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}