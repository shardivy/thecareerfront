import React, { useState } from "react";
import "./landing.css";

export default function AbroadCounselling() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT (IMAGE SAME) */}
      <div className="left">
        <div className="flyer-card">
          <img src="/Abroad-Counselling-Flayer.jpeg" alt="Abroad Counselling Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* 🔽 SCROLL CONTENT */}
          <div className="scroll-content">

            <h1>ABROAD ADMISSION COUNSELLING</h1>

            <p><b>abroad counselling - expert Abroad counseling service</b></p>

            <div className="list-cards">

              <div className="list-card">
                <b>Providing Continuous Support From Inquiry To Enrollment & Beyond.</b>
              </div>

              <div className="list-card">
                <b>Offering Personalized Support Tailored To Individual Goals & Aspirations.</b>
              </div>

              <div className="list-card">
                <b>Guidance & Resources For Standardized Tests Like SAT, ACT, TOEFL, & IELTS.</b>
              </div>

              <div className="list-card">
                <b>Assistance With Application Completion, Essay Writing, & Document Preparation.</b>
              </div>

              <div className="list-card">
                <b>Comprehensive Knowledge Of Global Admission Procedures, Criteria, & Patterns.</b>
              </div>

              <div className="list-card">
                <b>Join now to make your admission journey seamless and informed!</b>
              </div>

            </div><br></br>

            <h3>🏦 Abhinav Career Scope, Pune</h3>

            <p>📞 9922695424 / 8208030557</p>

          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>WhatsApp / Call</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>

    </div>
  );
}