import React, { useState } from "react";
import "./landing.css";

export default function Apti10() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/8-12Aptitude-Flayer.jpeg" alt="10th Aptitude Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>Career Guidance for 10th Students</h1>

            <p>
              Finished or preparing for your 10th board exams? 🎯
              Confused about choosing the right stream after 10th?
            </p>

            <p>
              Choosing between <b>Science, Commerce, Arts, Diploma, or other career paths</b> can feel overwhelming. 
              <b> Abhinav Career Scope</b> helps students make confident and informed decisions based on their interests, strengths, and future goals. 🚀
            </p>

            <h3>🌟 Meet Your Mentor: Reena Bhutada</h3>

            <p>
              Learn from <b>Reena Bhutada</b>, a National Award-Winning Career Counselor, who has guided thousands of students toward successful academic and career journeys.
            </p>

            <h3>🧠 What We Offer</h3>

            <p>
              Our career guidance program for 10th students is specially designed to help students select the right stream and career direction with clarity and confidence.
            </p>

            <div className="list-cards">

              <div className="list-card">
                <b>Scientific Aptitude Test</b>
                <p>
                  Discover your strengths, personality, interests, and skills through professional aptitude analysis.
                </p>
              </div>

              <div className="list-card">
                <b>Stream Selection Guidance</b>
                <p>
                  Get expert guidance to choose the right stream after 10th based on your capabilities and career goals.
                </p>
              </div>

              <div className="list-card">
                <b>Career Counselling Sessions</b>
                <p>
                  Personalized counselling for students and parents to explore future career opportunities and educational paths.
                </p>
              </div>

            </div>

            <br />

            <h3>📚 Why Career Guidance After 10th?</h3>

            <ul>
              <li>Choose the right stream with confidence</li>
              <li>Understand future career opportunities</li>
              <li>Avoid confusion and wrong career choices</li>
              <li>Build a strong foundation for future success</li>
            </ul>

            <h3>📞 Get Started Today!</h3>

            <p>
              Your career journey begins with the right decision after 10th. Take the first step toward a brighter future today. 🌈
            </p>

            <ul>
              <li>
                Scan the QR Code in the flyer to join our WhatsApp Group for updates, counselling information, and career guidance tips.
              </li>
            </ul>

          </div>

          {/* STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Call Us Directly</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> – Your Perfect Career Guide.
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}