import React, { useState } from "react";
import "./landing.css";

export default function AdmissionCounselling() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/Engg-EndToEnd-Flayer.jpeg" alt="Admission Counselling Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right" style={{ padding: 26 }}>
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>Expert Engineering Online Session</h1>

            <p>
              Confused about your JEE or CET results? 🧱 Turn your rank into a roadmap with our <b>Expert Engineering Online Session</b>!
            </p>

            <p>
              The engineering admission process can be a complex puzzle of percentiles, cutoffs, and branch preferences. At <b>Abhinav Career Scope</b>, we simplify the process so you can secure the best possible college based on your performance. 🚀
            </p>

            {/* INNER CARD */}
            <div className="inner-card">
              <h3>🔍 What to Expect in This Session:</h3>

              <div className="list-cards">
                <div className="list-card">
                  <b>Percentile & Rank Discussion</b>
                  <p>Understand where you stand in competition.</p>
                </div>

                <div className="list-card">
                  <b>College & Branch Options</b>
                  <p>Find best colleges & streams for your rank.</p>
                </div>

                <div className="list-card">
                  <b>Admission Process Q&A</b>
                  <p>Clear doubts about CAP rounds & counseling.</p>
                </div>

                <div className="list-card">
                  <b>Ongoing Support</b>
                  <p>Join WhatsApp group for updates till admission.</p>
                </div>
              </div>
            </div><br></br>

            <h3>🎓 Guided by Reena Bhutada</h3>
            <p>
              Learn from a seasoned expert in Maharashtra & national admission cycles.
            </p>

            <h3>⚠️ Important Notes</h3>
            <ul>
              <li>Single session only — no follow-up calls.</li>
              <li>Rank analysis must be done independently.</li>
            </ul>

            <h3>📞 Take Control of Your Future</h3>
            <p>Slots fill fast. Book your consultation now!</p>
<button
              className="cta"
              onClick={() =>
                window.open(`https://wa.me/91${phone1.replace(/\D/g, "")}`)
              }
            >
              💬 Consult Now
            </button>
          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            

            <div>
              <h3>Connect with Us</h3>
              <p>Your career deserves expert guidance.</p>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              Abhinav Career Scope — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}