import React, { useState } from "react";
import "./landing.css";

export default function MedicalEndToEnd() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">
      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/Medical-EndToEnd-Flayer.jpeg" alt="Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>Medical End-to-End Admission Guidance</h1>

            <p className="intro">
              Navigating the road to a medical degree can be overwhelming, but you don't have to walk it alone! 🩺✨
              <br /><br />
              <b>Abhinav Career Scope</b> presents <b>Medical End-to-End Admission Process Guidance</b>, simplifying every step from NEET exams to final allotment.
            </p>

            <h3>🏥 Complete Medical Admission Support</h3>
            <p>
              We provide a 360-degree approach so you don’t miss your dream college.
            </p>

            <div className="features">
              <Feature title="NEET UG Guidebook" desc="Your essential manual for the admission journey." />
              <Feature title="Expert Webinars" desc="Unlimited sessions with experts." />
              <Feature title="2 Counselling Sessions" desc="Personalized career guidance." />
              <Feature title="Post-Result Counselling" desc="Smart strategy after results." />
              <Feature title="Application Assistance" desc="AIQ, AIIMS, AFMC & more." />
            </div>

            <h3>🌐 Online + Offline Support</h3>
            <p>
              Join hundreds of NEET aspirants who trust us for their career journey.
            </p>
 <button
              className="cta"
              onClick={() =>
                window.open(`https://wa.me/91${phone1.replace(/\D/g, "")}`)
              }
            >
              💬 Book Counselling
            </button>
          </div>

          {/* 🔽 FIXED BOTTOM */}
          <div className="fixed-bottom">

           
<div><h3>Connect with Us</h3>
            <p>Your medical career deserves expert guidance.</p></div>
            

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              Abhinav Career Scope — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}

function Feature({ title, desc }) {
  return (
    <div className="feature-card">
      <div className="feature-title">{title}</div>
      <div className="feature-desc">{desc}</div>
    </div>
  );
}