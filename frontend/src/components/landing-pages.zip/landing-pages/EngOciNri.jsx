import React, { useState } from "react";
import "./landing.css";

export default function EngOciNri() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/OCI-NRI-Flayer.jpeg" alt="OCI/NRI Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>NRI / OCI / CIWG / PIO Engineering Admission 2026</h1>

            <p>
              Attention all OCI, NRI, CIWG, and PIO engineering aspirants! 🎓✨ Navigating the 2026 admission cycle requires precision, timing, and expert knowledge. <b>Abhinav Career Scope</b> is here to ensure your journey to a top engineering college is smooth and successful with our exclusive <b>Admission WhatsApp Paid Group!</b>
            </p>

            <h3>🚀 Why Join Our Specialized 2026 Admission Group?</h3>

            <p>
              We provide comprehensive support tailored to the unique needs of international and non-resident Indian students:
            </p>

            <div className="list-cards">

              <div className="list-card">
                <b>Document Verification</b>
                <p>
                  Check all your documents NOW to ensure anything missing can be completed well before critical deadlines.keep all each and every word
                </p>
              </div>

              <div className="list-card">
                <b>Process Roadmap</b>
                <p>
                  Get a clear, detailed timeline of the entire admission process to stay ahead of the curve.
                </p>
              </div>

              <div className="list-card">
                <b>College Insights</b>
                <p>
                  Explore all available options for colleges that cater to your specific quota and academic goals.
                </p>
              </div>

              <div className="list-card">
                <b>Strategic Prioritization</b>
                <p>
                  Learn how to prioritize your choices based on results, preferred city, state, and your specific budget.
                </p>
              </div>

              <div className="list-card">
                <b>Real-Time Support</b>
                <p>
                  Stay updated with the latest instructions and ensure you are available for every critical step of the cycle.
                </p>
              </div>

            </div><br></br>

            <h3>💼 Professional Mentorship</h3>

            <p>
              With over <b>18 years of experience</b> in career counseling and student advocacy, we specialize in bridging the gap between global education and employability. Let our expertise guide you toward your perfect engineering career.
            </p>

            <h3>📞 Connect With Us Today</h3>

            <p>
              Don't leave your 2026 engineering admission to chance. Join our paid WhatsApp group for premium updates and expert guidance.
            </p>

            <ul>
              <li><b>Location:</b> Bavdhan, Pune, India</li>
            </ul>

          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Call / WhatsApp</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}