import React, { useState } from "react";
import "./landing.css";

export default function EleventhAdmission() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/11thAdmission-Flayer.png" alt="11th Admission Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>11th Admission State Board (Pune)</h1>

            <p>
              <b>Perfect Career Guide</b> — A dedicated WhatsApp group exclusively for parents to simplify the 11th admission journey.
            </p>

            <h3>🏫 Group Exclusively for Parents</h3>

            <p>
              Get complete guidance and real-time updates to ensure a smooth admission process.
            </p>

            <div className="list-cards">

              <div className="list-card">
                <b>PMC Scholarship</b>
                <p>Detailed information and guidance on scholarship opportunities.</p>
              </div>

              <div className="list-card">
                <b>Cut-Off Discussion</b>
                <p>Understand trends and expected cut-offs for better decisions.</p>
              </div>

              <div className="list-card">
                <b>Admission Process</b>
                <p>Step-by-step support to complete the process smoothly.</p>
              </div>

              <div className="list-card">
                <b>Roundwise Updates</b>
                <p>Stay updated with each admission round and important announcements.</p>
              </div>

              <div className="list-card">
                <b>Document Requirement</b>
                <p>Know all required documents beforehand to avoid last-minute issues.</p>
              </div>

              <div className="list-card">
                <b>Bifocal Subject Selection</b>
                <p>Expert guidance to choose the right subject combination.</p>
              </div>

              <div className="list-card">
                <b>Frequently Asked Questions</b>
                <p>Clear answers to common admission-related queries.</p>
              </div>

              <div className="list-card">
                <b>Coaching Institute Selection</b>
                <p>Recommendations for the best coaching institutes.</p>
              </div>

            </div><br></br>

            <h3>📞 Contact Us</h3>

            <p>
              Get expert guidance and secure your child’s future with confidence.
            </p>

            <ul>
              <li><b>Location:</b> Bavdhan, Pune</li>
            </ul>

          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>WhatsApp / Call</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}