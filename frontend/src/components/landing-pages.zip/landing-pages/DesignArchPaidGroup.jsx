import React, { useState } from "react";
import "./landing.css";

export default function DesignArchPaidGroup() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 9922695424";
  const phone2 = "+91 8208030557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/Design-Flayer.jpeg" alt="Architecture & Design Admission Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* SCROLL */}
          <div className="scroll-content">

            <h1>Counseling for Design & Architecture</h1>
            <p>
              Paid Group for B.Arch (Architecture) & B.Des (Bachelor of Design) Admission Process – 2025
            </p>
            <p>
              This group is designed to provide important updates and guidance for the 2025 B.Arch & B.Des Admission Process.
            </p>

            {/* HIGHLIGHTS */}
            <div className="inner-card">
              <h3>📌 What You’ll Get in This Group</h3>

              <div className="list-cards">
                <div className="list-card">
                  <b>Important Dates & Deadlines</b>
                </div>
                <div className="list-card">
                  <b>Entrance Exams Information</b>
                </div>
                <div className="list-card">
                  <b>Admission Process & Rules</b>
                </div>
                <div className="list-card">
                  <b>Option Form Tips & Guidance</b>
                </div>
                <div className="list-card">
                  <b>Q&A Support</b>
                </div>
                <div className="list-card">
                  <b>Answers to Frequently Asked Questions (FAQs)</b>
                </div>
              </div>
            </div>

            <p>
              Duration: This group will remain active until the 2025 B.Arch & B.Des Admission Process ends.
            </p>

            {/* NOTE */}
            <div className="inner-card">
              <h3>📌 Payment & Note</h3>

              <div className="list-cards">
                <div className="list-card">
                  <b>Entry Fees</b>
                  <p>Rs. 2000/-</p>
                </div>
                <div className="list-card">
                  <b>Payment Method</b>
                  <p>Gpay on 9922695424</p>
                </div>
                <div className="list-card">
                  <b>Group Addition</b>
                  <p>Send a Screenshot and one number to add to the group. Only one parent’s number will be added per payment; multiple additions will not be allowed.</p>
                </div>
                <div className="list-card">
                  <b>One-on-One Guidance</b>
                  <p>Available for a complete admission process on an individual basis. Charges will vary based on requirements.</p>
                </div>
              </div>
            </div>

          </div>

          {/* FOOTER */}
          <div className="fixed-bottom">
            <div>
              <h3>Contact Us</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>🏦 Abhinav Career Scope, Pune</b>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
