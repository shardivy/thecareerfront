import React, { useState } from "react";
import "./landing.css";

export default function PgCounselling() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 992 269 5424";
  const phone2 = "+91 820 803 0557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/PG-Counselling-Flayer.jpeg" alt="PG Counselling Flyer" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* 🔽 SCROLLABLE CONTENT */}
          <div className="scroll-content">

            <h1>PG Counselling Program</h1>

            <p>
              Ready to take the next leap in your academic and professional journey? 🎓 At <b>Abhinav Career Scope</b>, we provide a structured and comprehensive counseling process designed to help you navigate postgraduate studies with ease.
            </p>

            <p>
              Our end-to-end support is built to ensure you find the right fit and excel in your chosen field.
            </p>

            <h3>📘 Our PG Counseling Roadmap includes:</h3>

            <div className="list-cards">

              <div className="list-card">
                <b>1. Aptitude Test</b>
                <p>
                  We assess your personality, interests, and strengths to identify the best path for your future career.
                </p>
              </div>

              <div className="list-card">
                <b>2. India Options</b>
                <p>
                  Explore a wide range of PG courses across India, with deep dives into:
                </p>
                <ul>
                  <li>Detailed course curriculum. keep each and every word</li>
                  <li>Entrance exams and admission procedures.</li>
                  <li>Identifying top institutions and universities.</li>
                </ul>
              </div>

              <div className="list-card">
                <b>3. Preparation Resources</b>
                <p>
                  Gain access to essential study materials and references, including:
                </p>
                <ul>
                  <li>Curated online resources.</li>
                  <li>Mock tests and practice exams to build confidence.</li>
                  <li>Proven tips and strategies for success.</li>
                </ul>
              </div>

              <div className="list-card">
                <b>4. Internship & Job Discussion</b>
                <p>
                  We go beyond admissions by guiding you through:
                </p>
                <ul>
                  <li>Resume building and interview preparation.</li>
                  <li>Networking strategies and industry connections.</li>
                  <li>Career growth and long-term development opportunities.</li>
                </ul>
              </div>

            </div><br></br>

            <h3>📞 Plan Your Future with Experts</h3>

            <p>
              Led by a team with over <b>18 years of experience</b> in career mentorship, we are committed to bridging the gap between education and employability.
            </p>

          </div>

          {/* 🔽 STICKY FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Consult Now</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>Abhinav Career Scope</b> — Perfect Career Guide
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}