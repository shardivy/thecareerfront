import React, { useState } from "react";
import "./landing.css";

export default function HandHolding() {
  const [copied, setCopied] = useState(false);

  const phone1 = "+91 9922695424";
  const phone2 = "+91 8208030557";

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      alert("failed");
    }
  };

  return (
    <div className="container">

      {/* LEFT */}
      <div className="left">
        <div className="flyer-card">
          <img src="/HH-Flayer.jpeg" alt="Career Counselor Program" />
        </div>
      </div>

      {/* RIGHT */}
      <div className="right">
        <div className="card">

          {/* SCROLL */}
          <div className="scroll-content">

            <h1>Become a Certified Career Counselor!</h1>

            <p>
              At <b>Abhinav Career Scope</b>, we don’t just guide students, we empower future career counselors! Our hand-holding sessions equip passionate individuals with the skills and knowledge to guide students and parents with confidence.
            </p>

            <p>
              Whether you’re an educator, HR, industry expert, graduate, parent, or homemaker, if you’re passionate about career counseling, we are here to support you.
            </p>

            {/* FEATURES */}
            <div className="inner-card">
              <h3>🎓 Program Highlights</h3>

              <div className="list-cards">

                <div className="list-card">
                  <b>Real-world Training</b>
                  <p>Hands-on learning through 10 Live Sessions.</p>
                </div>

                <div className="list-card">
                  <b>Expert Learning</b>
                  <p>Learn from a nationally awarded career counselor.</p>
                </div>

                <div className="list-card">
                  <b>Flexible Learning</b>
                  <p>Online & offline sessions as per convenience.</p>
                </div>

                <div className="list-card">
                  <b>Mentorship Support</b>
                  <p>Ongoing personalized guidance for success.</p>
                </div>

              </div>
            </div><br></br>

            <h3>🚀 Start Your Journey</h3>

            <p>
              Join us and transform the future of career counseling!
            </p>

          </div>

          {/* FOOTER */}
          <div className="fixed-bottom">

            <div>
              <h3>Consult Now</h3>
            </div>

            <div className="phones">
              <button onClick={() => copy(phone1)}>📞 {phone1}</button>
              <button onClick={() => copy(phone2)}>📞 {phone2}</button>
            </div>

            {copied && <div className="copied">Copied!</div>}

            <div className="footer">
              <b>🏦 Abhinav Career Scope, Pune</b>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}